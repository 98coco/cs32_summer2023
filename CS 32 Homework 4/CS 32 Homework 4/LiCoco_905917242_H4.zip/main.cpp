//
//  main.cpp
//  CS 32 Homework 4
//
//  Created by Coco Li on 8/18/23.
//

#include <fstream>
#include <iostream>
#include <cctype>
#include <string>
#include <cassert>
#include "WordTree.h"
using namespace std;

int main() {
    
    return 0;
}
